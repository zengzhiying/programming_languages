<?php
print_r(get_loaded_extensions());
?>