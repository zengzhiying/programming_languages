<!DOCTYPE html>
<meta charset="utf-8" />
<h1><?php echo $title ?></h1>
