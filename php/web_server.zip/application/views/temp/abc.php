<?php
echo $stri;
echo $_GET['sks'];
?>