<?php
/**
 * 使用自定义类库，应该是公共类库，具体业务逻辑应该放到models中
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class Myclass {
	public function myclasstest($str) {
		return $str;
	}
}