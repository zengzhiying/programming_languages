<?php
class WebTest extends CI_Controller {
    public function view($page = 'home') {
        //获取方法参数值
        $data['title'] = ucfirst($page);
        $this->load->view('temp/test', $data);
    }
    public function fileaction() {
        file_put_contents("./phptext.out", "This is text");
    }

    public function myclasstest() {
    	//加载自定义类库 第二个参数可以向构造方法传值
    	$this->load->library("test/myclass");
    	//调用方法
    	$str = $this->myclass->myclasstest("ceshi");
    	echo $str;
    }

    public function routeTest() {
        $data = array('stri' => "abc", );
        $this->load->view("temp/abc", $data);
    }
}
?>
