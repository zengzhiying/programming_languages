<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/**
 * 可以同时接受get和post
 */
Route::match(['get', 'post'], '/test_request', function() {
    return "Hello get and post!";
});

/**
 * 定义路由指向一个控制器的某一个方法
 */
Route::get('/test_controll', 'TestController@show');

Route::get('/test_controll2', 'TestController@show1');

/**
 * 获取请求参数值
 */
Route::get('/request_test', 'TestController@request_test');

Route::get('/redirect_test', "TestController@redirect_test");

/**
 * 请求直接绑定url匹配参数 可以任意绑定需要的
 */
Route::get('/test/{id}/test/{name}', "TestController@show2");

/**
 * post请求测试
 */
Route::post('/post_test', "TestController@post_test");
/**
 * post发送
 */
Route::get('/send_post', 'TestController@send_post');

// session测试
Route::get('/session_test', 'TestController@session_test');

// 对密码hash测试
Route::get('/hash_test', 'TestController@hash_test');

// 数据库测试
Route::get('/db_test', 'TestController@db_test');
