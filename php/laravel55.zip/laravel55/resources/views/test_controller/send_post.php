<form action="/post_test" method="post">
    <input type="text" name="name">
    <?php echo csrf_field(); // post时必须发送此字段 ?>
    <input type="submit" />
</form>