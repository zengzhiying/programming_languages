<?php
// 指定命名空间 默认
namespace App\Http\Controllers;
// 导入对应的模块
// use App\User;
// 导入控制器模块 默认
use App\Http\Controllers\Controller;
// 导入Request模块
use Illuminate\Http\Request;
// 使用hash需要导入Hash模块
use Hash;
// 使用数据库需要导入模块
use Illuminate\Support\Facades\DB;

class TestController extends Controller
{
    /**
     * 路由对应的方法
     */
    public function show()
    {
        // 返回指定视图和指定的数据
        return view('test_controller.test', ["name" => "test1"]);
    }

    public function show1() {
        $name1 = "zzy";
        $name2 = array("zzy"=>'zzy2');
        // 传递多个值
        return view('test_controller.test')->with('name', $name1)->with('name2', $name2);
    }

    /**
     * 绑定request参数
     */
    public function request_test(Request $request) {
        header("Content-Type:text/html; charset=utf-8");
        // 获得请求方法
        $method = $request->method();
        echo $method;
        // 可以用下面方式判断请求
        if($request->isMethod('get')) {
            echo "是get请求...";
            // 获取参数值 默认不区分请求类型 值不存在不会报错
            $v = $request->input('name');
            echo $v;
        }
    }

    public function redirect_test() {
        // 或者redirect()->route("/request_test"), 如果传入参数可以redirect()->route("/request_test", ['id'=>'1'])
        return redirect('/request_test');
    }

    public function show2($id, $name) {
        echo "id:".$id;
        echo "name:".$name;
    }

    public function post_test(Request $request) {
        $r = $request->input("name");
        echo $r.'<br />';
        $a = $request->all();
        print_r($a);
    }

    public function send_post() {
        $v = view("test_controller.send_post");
        return $v;
    }

    public function session_test(Request $request) {
        // 原生方法 设置session浏览器端为PHPSESSID
        // session_start();
        // $_SESSION['user'] = 'zzy';
        // echo $_SESSION['user'];
        // laravel方法 全局方法 浏览器端默认为laravel_session所以两者不通用
        // session(['user' => 'zzys']);
        // $value = session('user');
        // echo $value;
        // laravel 使用request方法需要传入Request的参数
        // $request->session()->put('user', null);
        // 获取值
        // $v = $request->session()->get('user');
        // echo $v;
        // 获取一次就删除
        // $v = $request->session()->pull('user1');
        // echo $v;
        // 删除指定session
        // $request->session()->forget('user');
        // 删除所有session
        // $request->session()->flush();
        // echo $v;
        // 获取所有的session返回session数组
        // $data = $request->session()->all();
        // print_r($data);
        // 判断session的值是否存在并且不为null
        if($request->session()->has('user')) {
            echo "ok";
        } else {
            echo 'no';
        }
    }


    public function hash_test() {
        $p = "admin111";
        // $c_p = Hash::make($p);
        // echo $c_p;
        // 密码验证
        if(Hash::check($p, '$2y$10$af/z23.xHQm5Hp8Rcq2nPeYNCLKgKeRX9PIJIjJ4SK8Gb5ArRUXIO')) {
            echo "ok";
        } else {
            echo "error";
        }
        // 验证加密系数是否修改 是否需要重新加密
        // if (Hash::needsRehash($p)) {
        //     // 重新加密操作
        //     echo "hash";
        // } else {
        //     echo 'f hash';
        // }
    }

    public function db_test() {
        header('Content-Type:text/html; charset=utf-8');
        // 查询1条
        $rs = DB::table('test1')->where('id', 1)->first();
        print_r($rs);
        echo $rs->user_name;
        // 查询指定字段和条件的记录
        $rs = DB::table('test1')->select('id', 'user_name')->where('id', '>=', 2)->orWhere('user_name','李淑丽')->orderBy('id', 'desc')->get();
        foreach($rs as $key => $value) {
            echo $key;
            print_r($value);
        }
        $rs = DB::table('test1')->select('id', 'user_name')->where([
            ['id', '>=', 2],
            ['user_name','like','%曾%']
            ])->orderBy('id', 'desc')->get();
        foreach($rs as $key => $value) {
            echo $key;
            print_r($value);
        }
        // 统计
        $rs = DB::table('test1')->where('id', '>' , 1)->count();
        echo $rs;
        echo '<br />';
        $rs = DB::table('test1')->max('id');
        echo $rs.'<br />';
        // 插入
        // $data = array(
        //     array('user_name'=>'mon'),
        //     array('user_name'=>'mon2'),
        //     );
        // $rs = DB::table('test1')->insert($data);
        // echo $rs;
        // 更新
        // $rs = DB::table('test1')->where('id','>', 6)->update(["user_name"=>'曾智颖和李淑丽的小孩']);
        // echo "hh".$rs;
        // 删除
        $rs = DB::table('test1')->whereBetween('id',[4, 6])->delete();
        echo $rs;
        // 清空数据表所有数据 并将自增id设置为零 一般用工具清空数据表并不设置为0
        // DB::table('test1')->truncate();
        // 操作非默认的库连接
        DB::connection('mysql_style1')->select('set names utf8');
        // 查询操作 带参数绑定 关于插入insert 更新update 删除delete等操作基本一致
        $rs1 = DB::connection('mysql_style1')->select('select * from fy_cate where cate_id > ? and cate_id < ?', [1, 100]);
        print_r($rs1);
    }
}