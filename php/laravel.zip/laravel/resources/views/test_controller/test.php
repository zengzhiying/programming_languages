<html>
<body>
    <?php
    echo "Hello ".$name;
    ?>
    <?php
    try {
        echo $name2['zzy'];
    } catch (Exception $e) {
        // echo $e;
        echo "no value!";
    }
    ?>
</body>
</html>