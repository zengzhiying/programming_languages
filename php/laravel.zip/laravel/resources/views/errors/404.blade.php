<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>404</title>
</head>
<body>
    <p>This is 404!</p>
    {{ phpversion() }}
</body>
</html>